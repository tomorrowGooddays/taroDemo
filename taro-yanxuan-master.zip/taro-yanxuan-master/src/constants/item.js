export const ITEM_INFO = 'ITEM_INFO'
export const ITEM_RECOMMEND = 'ITEM_RECOMMEND'
