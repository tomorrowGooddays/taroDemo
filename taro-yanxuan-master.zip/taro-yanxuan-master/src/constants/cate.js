export const CATE_MENU = 'CATE_MENU'
export const CATE_SUB = 'CATE_SUB'
export const CATE_SUB_LIST = 'CATE_SUB_LIST'
